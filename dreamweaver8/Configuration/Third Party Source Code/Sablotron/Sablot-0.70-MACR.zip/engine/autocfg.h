/* autocfg/autocfg.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the isnan function */
#define HAVE_ISNAN

/* Define if you have the isinf function */
#define HAVE_ISINF

/* Define if you have the finite function */
#define HAVE_FINITE

/* Define if you have wchar.h header */
#define HAVE_WCHAR_H

/* Define if don't want to generate the META html tag */
#undef SABLOT_DISABLE_ADDING_META

/* define whether second param of iconv has to be typecasted */
#undef SABLOT_ICONV_CAST_OK

/* Define if you have the ftime function.  */
#undef HAVE_FTIME

/* Define if you have the gettimeofday function.  */
#undef HAVE_GETTIMEOFDAY

/* Define if you have the iconv_open function.  */
#undef HAVE_ICONV_OPEN

/* Define if you have the mtrace function.  */
#undef HAVE_MTRACE

/* Define if you have the wcsxfrm function.  */
#define HAVE_WCSXFRM

/* Define if you have the <expat.h> header file.  */
#define HAVE_EXPAT_H

/* Define if you have the <iconv.h> header file.  */
#undef HAVE_ICONV_H

/* Define if you have the <ieeefp.h> header file.  */
#undef HAVE_IEEEFP_H

/* Define if you have the <sys/time.h> header file.  */
#undef HAVE_SYS_TIME_H

/* Define if you have the <sys/timeb.h> header file.  */
#undef HAVE_SYS_TIMEB_H

/* Define if you have the <sys/types.h> header file.  */
#undef HAVE_SYS_TYPES_H

/* Define if you have the <timeb.h> header file.  */
#undef HAVE_TIMEB_H

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H

/* Define if you have the <xmlparse.h> header file.  */
#undef HAVE_XMLPARSE_H

/* Define if you have the <xmltok/xmlparse.h> header file.  */
#undef HAVE_XMLTOK_XMLPARSE_H
