// This header is included with every file for the Mac build

#define _MAC
// #define XP_MAC 1

#ifdef __MACH__
#include <MSLCarbonPrefix.h>
#include <Carbon/Carbon.h>
#else
// include this next line ONLY if using MSL as a dll
// this includes any staticly linked library into DW/UD
#include "UseDLLPrefix.h"	
#endif

#include "mfc2pp.carb.opt"
#include "mfc2x.opt"

#define JSFILE
#define MFC2X

